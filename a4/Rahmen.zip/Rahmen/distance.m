function err = distance(F,correspondences)
%DISTANCE Compute distance to corresponding epipolar line
% F - fundamental matrix
% correspondences - corresponding points between left and right image
    err = 0;
    
    % place your code here
end

